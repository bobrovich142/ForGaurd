@echo off
:start
echo ============
echo        friend
echo ============
echo.
echo you You're walking alone in the park...
echo You meet a friend
echo Time: 11:56 PM
echo friend: what you did on the street in 11:56 PM?
echo.
echo 1) I just decided to take a walk
echo.
set /p var=Set Command:
if %var%==1 goto i just  decided to take a walk
:i fust decided to take a walk
cls 
echo friend: strange, oh well, okay, bye
echo you go to the next, go park
echo you thought 
color 4
echo What if they tie me up?
color 7
echo you go next
echo.
echo you looking man You saw a man behind the tree.
echo what will you do?
echo.
echo 1) run
echo 2) go next
echo.
set /p var=Set Command:
if %var%==1 goto run
if %var%==2 goto go next
:run
cls 
echo you ran out of the forest
echo you go to the home
echo.
echo you home
echo.
echo you go to sleep
echo.
echo 1 day
echo.
echo you go on the work
echo.
echo You saw the man again, but he was looking at you...
echo.
echo you on work
echo.
echo You saw a silhouette.
echo The light went out...
echo.
echo what will you do now?
echo.
echo 1) on the light
echo 2) run from work
echo.
set /p var=Set Command:
if %var%==1 goto on the light 
if %var%==2 goto run from work
:on the light 
cls 
echo It won't help you
echo the silhouette killed you
pause 
goto start
:run from work 
cls 
echo you run
echo you... you ran away!
pause 
goto start
:go next
cls
echo you were grabbed and taken away
echo you were brought to the forest
echo what will you do?
echo.
echo 1) make a deal
echo 2) escape from the forest
set /p var=Set Command:
if %var%==1 make a deal
if %var%==2 escape from the forest
:make a deal
cls
echo You made a deal
echo you leave alive and unharmed
echo you go home 
echo.
echo end game
echo.
pause
cls
goto start