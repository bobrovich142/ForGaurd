@echo off
:start 
echo ==================
echo  Survival In The Forest
echo ==================
echo.
echo 1) story 1
echo 2) story 2 
echo 3) story 3
echo.
set /p var=Set Command: 
if %var%==1 goto story 1
if %var%==2 goto story 2
if %var%==3 goto story 3
:story 1
cls
echo you You were in an accident and woke up in the middle of the forest.You have to choose.
echo.
echo 1)  will look around
echo 2)  find a way out
echo.
set /p var=Set Command:
if %var%==1 goto look 
if %var%==2 goto way out 
:way out 
cls
echo You got lost, panic set in, you died of hunger. 
echo.
pause 
goto start
:look 
echo You are thinking of building a hut.
echo. 
echo use)   stick
echo use)  axe
echo.
set /p var=Set Command:
if %var%==use goto stick
if %var%==use goto axe
:stick 
cls 
echo You built a hut, you need to find food
echo You found 3 biomes, each of them has bushes with berries.
echo.
echo snack on) berries
echo snack on) potatos
echo snack on) apple 
echo.
set /p var=Set Command:
if %var%==snack on goto berries
if %var%==snack on goto patatos
if %var%==snack on goto apple

:apple
cls
echo you ate well
pause 
goto berries

:patatos
cls
echo The potatoes were poisoned, you died from poisoning.
pause 
goto start

:berries
cls
echo you ate well
echo You ate, night fell.
echo You woke up from the noise.
echo It was a wolf, how will you defend yourself?
echo.
echo 1) I won't do anything
echo 2) I'll put my hand in front of the wolf
set /p var=Set Command:
if %var%==1 goto anything
if %var%==2 goto hand in front of the wolf
:anything
cls
echo The wolf bit you, you died of rabies.
pause
goto start

:hand in front of the wolf
cls 
echo You threw the dog away, what will you do next?
echo.
echo 1) run
echo 2)finish off the wolf
echo.
set /p var=Set Command:
if %var%==1 goto run
if %var%==2 goto finish off the wolf
:run 
cls 
echo the wolf caught up with you and killed you
pause
goto start
:finish off the wolf
cls 
echo you killed a wolf 
echo you decided to take a walk
echo you found a village 
echo to go or to leave
echo.
echo 1) go
echo 2) leave
echo.
set /p var=Set Command:
if %var%==1 goto go
if %var%==2 goto leave
:go
cls
echo you  found residents of this village.
echo Skip to story 2 to continue.
pause
goto start
:leave
cls
echo to be continued...
pause 
goto finish off the wolf
:axe
cls
echo You don't have an axe with you.
echo.
pause
goto start






